

TOKEN = "yourToken"
URL = 'https://mboretto.github.io/easy-qr-scan-bot/'
URL_TEST = 'https://testurl'
